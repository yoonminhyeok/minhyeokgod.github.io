const express = require('express')
const ejs= require('ejs')
const app = express()
const port = 3000

const bodyParser = require('body-parser');


require('dotenv').config()

const mysql = require('mysql2')
const connection = mysql.createConnection(process.env.DATABASE_URL)
console.log('Connected to PlanetScale!')


app.set('view engine','ejs')
app.set('views','./views')
//라우터 

app.use(bodyParser.urlencoded({ extended: false} ));

app.use('/styles', express.static('styles'));


   



app.get('/', (req, res) => { // .views/index.ejs
  
    connection.query('SELECT * FROM contact', function (err, results) {
      if (err) {
        console.log('데이터베이스에서 데이터를 가져오는 중 오류 발생:', err);
        res.render('index', { List: [] }); // 오류 발생 시 빈 배열 전달
      } else {
        console.log('데이터베이스에서 데이터를 성공적으로 가져옴:', results);
        // 가져온 데이터를 index 뷰에 전달
        res.render('index', { List: results });
      }
    });
})

app.get('/contactDelete', (req, res) => {
    var idx=req.query.idx
    var sql=`select * from contact order by idx desc`
    connection.query(sql,function(err,result){
      if(err) 
      { 
        throw err;
      }
      else{
        res.send("<Script>location.href='/' </Script>"  )
      }
    })
  })



app.post('/contactProc', (req, res) => {  
    
   const list=req.body.list;
   
   var sql=`insert into contact(value) values('${list}')`
   var a=`${list}`

   connection.query(sql, function (err,result){
    if(err){
      throw err;
    }
    console.log("자료 1개를 삽입했습니다");
    res.send("<Script>location.href='/' </Script>"  )
   })

   

 


})


app.listen(port, () => {
  console.log(`서버가 실행되었습니다 접속주소: http://localhost:${port}`)
})
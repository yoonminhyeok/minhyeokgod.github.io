// app.js

const express = require('express');
const ejs = require('ejs');
const app = express();
const port = 3000;

const bodyParser = require('body-parser');
require('dotenv').config()

const mysql = require('mysql2')
const connection = mysql.createConnection('mysql://fiqcfpn7bipn06u5zrh3:pscale_pw_atpjzsam2L82UB4vVDvxR5vJJBeUDCt5DQdDY7Is5wp@aws.connect.psdb.cloud/unidago?ssl={"rejectUnauthorized":true}')


console.log('Connected to PlanetScale!')

app.set('view engine', 'ejs');
app.set('views', './views');

// 미들웨어 설정
app.use(bodyParser.urlencoded({ extended: false }));
app.use('/styles', express.static('styles'));

// 메인 페이지 라우팅
app.get('/', (req, res) => {
    connection.query('SELECT * FROM contact', function (err, results) {
        if (err) {
            throw err;
        } else {
            console.log('데이터베이스에서 데이터를 성공적으로 가져옴:', results);
            // 가져온 데이터를 index 뷰에 전달
            res.render('index', { List: results });
        }
    });
});

// 삭제 기능 라우팅
app.get('/contactDelete', (req, res) => {
    var idx = req.query.idx;
    var sql = `DELETE FROM contact WHERE idx = ${idx}`;
    
    connection.query(sql, function (err, result) {
        if (err) {
            throw err;
        } else {
            console.log("자료 1개를 삭제했습니다");
            res.send("<Script>location.href='/' </Script>"  )
        }
    });
});

// 추가 기능 라우팅
app.post('/contactProc', (req, res) => {
    const list = req.body.list;
    var sql = `INSERT INTO contact(value) VALUES('${list}')`;

    connection.query(sql, function (err, result) {
        if (err) {
            throw err;
        }
        console.log("자료 1개를 삽입했습니다");
        res.send("<Script>location.href='/' </Script>"  )
    });
});

// 서버 시작
app.listen(port, () => {
    console.log(`서버가 실행되었습니다. 접속 주소: http://localhost:${port}`);
});
